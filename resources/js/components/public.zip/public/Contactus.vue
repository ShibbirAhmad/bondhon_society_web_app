<template>
  <div class="wrapper-wide">
    <loading
      :active.sync="isLoading"
      :can-cancel="true"
      :is-full-page="fullPage"
    ></loading>

    <frontend-header></frontend-header>
    <div id="container">
      <div class="container">
        <div class="row">
          <!--Middle Part Start-->
          <div id="content" class="col-sm-12">
            <div class="row">
              <div class="col lg-12 col-md-12 col-sm-12 text-center">
                <h4 class="heading"><span>CONTACT US</span></h4>
              </div>
            </div>
            <div class="row contact_row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="row">
                  <div class="col-md-2 col-sm-2"></div>
                  <div class="col-md-8 col-sm-12 bg-white shadow">
                    <div class="address_container">
                      <p v-html="contact_info" class="address_details">
                       
                      </p>
          
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4"></div>
                </div>
                <br />
              </div>
            </div>
            <div class="row">
              <div class="col-sm-12">
                <div class="row">
                  <div class="col-lg-2 col-md-2 col-sm-2"></div>

                  <div class="col-lg-8 col-md-8 col-sm-10 box shadow bg-white">
                    <div class="text-center">
                      <h5 class="heading">
                        send us message, our customer service will be response.
                      </h5>
                    </div>
                    <form @submit.prevent="sendMessage()" method="post">
                      <div class="form-group">
                        <label for="name">Name</label>
                        <input class="form-control" type="text" v-model="name" />
                      </div>

                      <div class="form-group">
                        <label for="name">Email</label>
                        <input class="form-control" type="emial" v-model="email" />
                      </div>

                      <div class="form-group">
                        <label for="name">Message</label>
                        <textarea
                          v-model="message"
                          class="form-control"
                          rows="5"
                        ></textarea>
                      </div>
                      <div class="form-group text-center">
                      <input type="submit" class="btn btn-lg submit_style" value="send" />
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--Middle Part End -->
        </div>
      </div>
    </div>

    <frontend-footer></frontend-footer>
  </div>
</template>
<script>
import Loading from "vue-loading-overlay";
import "vue-loading-overlay/dist/vue-loading.css";
export default {
  created() {
    this.getContactInfo();
  },
  data() {
    return {
      isLoading: true,
      fullPage: true,
      name: "",
      email: "",
      message: "",
      contact_info:"",
    };
  },
  methods: {
    getContactInfo(){
         axios.get('/_public/api/get/info/abou/contact')
         .then(resp=>{
           console.log(resp);
           if (resp.data.status=="OK") {
             this.contact_info=resp.data.setting.contact_info ;
             this.isLoading=false;
           }
         })
     },
    sendMessage() {
      axios
        .post("/_public/customer/contact", {
          name: this.name,
          email: this.email,
          message: this.message,
        })
        .then((resp) => {
          if (resp.data.success == "OK") {
            Swal.fire({
              type: "success",
              text: "Thanks for your message, we will reply as soon as possible",
              confirm: true,
              duration: 4000,
              position: "top-center",
            });
            this.name = "";
            this.email = "";
            this.message = "";
          } else {
            Swal.fire({
              type: "error",
              text: "something went wrong. please, try again ",
              position: "top-center",
            });
          }
        });
    },
  },
  components: {
    Loading,
  },
};
</script>

<style scoped>
.submit_style {
  margin-bottom: 20px;
  width: 80px;
  background:green;
  border: dashed 1px;
  color: #fff;
  font-size: 16px;
}
.address_container {
  margin-top: 30px;
  margin-bottom: 50px;
}
@media screen and (max-width: 450px) {
  .address_container {
    margin-top: 30px;
    margin-left: 10px;
    margin-right: 10px;
    margin-bottom: 50px;
  }
  .contact_row {
    margin-top: -15px;
  }
  .address_container p {
    position: relative;
    font-size: 13px;
    line-height: 15px;
  }
  .box {
    margin: 10px;
  }
}
.address_container {
    padding: 10px;
}
.address_container i {padding-right: 15px;color: #ff4d03;}

.address_details{
  font-size:14px;
}


</style>